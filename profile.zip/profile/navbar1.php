<nav class="navbar navbar-expand-sm navbar-light">
        <div class="container">
            <a class="navbar-brand" href="profile\profile1.php"><i class='uil uil-user'></i> Suresh Kumar</a>

            <!--<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false"
                aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
                <span class="navbar-toggler-icon"></span>
                <span class="navbar-toggler-icon"></span>
            </button>-->
            <br><br><br><br>

            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav mx-auto">
                    <li class="nav-item">
                        <a href="#about" class="nav-link"><span data-hover="About">About</span></a>
                    </li>
                    <li class="nav-item">
                        <a href="#project" class="nav-link"><span data-hover="Experience">Experience</span></a>
                    </li>
                    <li class="nav-item">
                        <a href="#resume" class="nav-link"><span data-hover="Reviews">Reviews</span></a>
                    </li>
                    <li class="nav-item">
                        <a href="#contact" class="nav-link"><span data-hover="Contact">Contact</span></a>
                    </li>
                </ul>

                <div class="collapse navbar-collapse" id="navbarNav">
          
                <ul class="navbar-nav mx-auto">
                  <li class="current" class="nav-item" >
                    <a href="#" class="nav-link"><i class="fa fa-home" style="font-size:24px"></i></a></li>
                  <li class="nav-item" >
                    <a href="#" class="nav-link"><i class="fa fa-search" style="font-size:24px"></i></a></li>
                  <li class="nav-item" >
                    <a href="#" class="nav-link"><i class="fa fa-folder" style="font-size:24px"></i></a></li>
                    <li class="nav-item" >
                      <a href="#" class="nav-link"><i class="fa fa-bell" style="font-size:24px"></i></a></li>
              </ul>
            </div>

                

                <ul class="navbar-nav ml-lg-auto">
                   <!-- <div class="ml-lg-4">
                      <div class="color-mode d-lg-flex justify-content-center align-items-center">
                        <i class="color-mode-icon"></i>
                        Color mode
                      </div>
                    </div>-->
                </ul>
            </div>
        </div>
    </nav>